# STUDENT MANAGEMENT SYSTEM - API DOCUMENTATION

## Base URL
```
http://localhost:8080/api
```

---

## 📋 TABLE OF CONTENTS
1. [Authentication APIs](#authentication-apis)
2. [Student Management APIs](#student-management-apis)
3. [Search & Filter APIs](#search--filter-apis)
4. [Error Responses](#error-responses)
5. [Testing with Postman](#testing-with-postman)

---

## 🔐 AUTHENTICATION APIS

### 1. Register Admin User
**Endpoint:** `POST /api/auth/register`

**Description:** Register a new admin user

**Request Body:**
```json
{
  "username": "admin",
  "email": "admin@example.com",
  "password": "admin123"
}
```

**Success Response (201 Created):**
```json
{
  "message": "Registration successful",
  "username": "admin"
}
```

**Error Response (409 Conflict):**
```json
{
  "message": "Username already exists"
}
```

---

### 2. Login
**Endpoint:** `POST /api/auth/login`

**Description:** Login as admin user

**Request Body:**
```json
{
  "username": "admin",
  "password": "admin123"
}
```

**Success Response (200 OK):**
```json
{
  "message": "Login successful",
  "username": "admin",
  "email": "admin@example.com",
  "role": "ADMIN",
  "success": true
}
```

**Error Response (401 Unauthorized):**
```json
{
  "message": "Invalid username or password",
  "success": false
}
```

---

### 3. Check Username Availability
**Endpoint:** `GET /api/auth/check-username?username=admin`

**Description:** Check if username already exists

**Success Response (200 OK):**
```json
{
  "exists": true
}
```

---

## 👨‍🎓 STUDENT MANAGEMENT APIS

### 1. Create Student
**Endpoint:** `POST /api/students`

**Description:** Add a new student to the system

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "john.doe@example.com",
  "department": "Computer Science",
  "year": 3,
  "phoneNumber": "9876543210"
}
```

**Validation Rules:**
- `name`: Required, 2-100 characters
- `email`: Required, valid email format, unique
- `department`: Required, max 50 characters
- `year`: Required, between 1-4
- `phoneNumber`: Required, exactly 10 digits

**Success Response (201 Created):**
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john.doe@example.com",
  "department": "Computer Science",
  "year": 3,
  "phoneNumber": "9876543210"
}
```

**Error Response (400 Bad Request) - Validation Error:**
```json
{
  "timestamp": "2024-01-07T10:30:00",
  "status": 400,
  "error": "Validation Failed",
  "errors": {
    "email": "Email should be valid",
    "phoneNumber": "Phone number must be 10 digits"
  },
  "path": "/api/students"
}
```

**Error Response (409 Conflict) - Duplicate Email:**
```json
{
  "timestamp": "2024-01-07T10:30:00",
  "status": 409,
  "error": "Conflict",
  "message": "Student with email john.doe@example.com already exists",
  "path": "/api/students"
}
```

---

### 2. Get All Students
**Endpoint:** `GET /api/students`

**Description:** Retrieve all students

**Success Response (200 OK):**
```json
[
  {
    "id": 1,
    "name": "John Doe",
    "email": "john.doe@example.com",
    "department": "Computer Science",
    "year": 3,
    "phoneNumber": "9876543210"
  },
  {
    "id": 2,
    "name": "Jane Smith",
    "email": "jane.smith@example.com",
    "department": "Electronics",
    "year": 2,
    "phoneNumber": "9876543211"
  }
]
```

---

### 3. Get Student by ID
**Endpoint:** `GET /api/students/{id}`

**Description:** Retrieve a specific student by ID

**Example:** `GET /api/students/1`

**Success Response (200 OK):**
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john.doe@example.com",
  "department": "Computer Science",
  "year": 3,
  "phoneNumber": "9876543210"
}
```

**Error Response (404 Not Found):**
```json
{
  "timestamp": "2024-01-07T10:30:00",
  "status": 404,
  "error": "Not Found",
  "message": "Student not found with id : '1'",
  "path": "/api/students/1"
}
```

---

### 4. Update Student
**Endpoint:** `PUT /api/students/{id}`

**Description:** Update an existing student's details

**Example:** `PUT /api/students/1`

**Request Body:**
```json
{
  "name": "John Doe Updated",
  "email": "john.updated@example.com",
  "department": "Computer Science",
  "year": 4,
  "phoneNumber": "9876543210"
}
```

**Success Response (200 OK):**
```json
{
  "id": 1,
  "name": "John Doe Updated",
  "email": "john.updated@example.com",
  "department": "Computer Science",
  "year": 4,
  "phoneNumber": "9876543210"
}
```

**Error Response (404 Not Found):**
```json
{
  "timestamp": "2024-01-07T10:30:00",
  "status": 404,
  "error": "Not Found",
  "message": "Student not found with id : '1'",
  "path": "/api/students/1"
}
```

---

### 5. Delete Student
**Endpoint:** `DELETE /api/students/{id}`

**Description:** Delete a student from the system

**Example:** `DELETE /api/students/1`

**Success Response (200 OK):**
```json
{
  "message": "Student deleted successfully"
}
```

**Error Response (404 Not Found):**
```json
{
  "timestamp": "2024-01-07T10:30:00",
  "status": 404,
  "error": "Not Found",
  "message": "Student not found with id : '1'",
  "path": "/api/students/1"
}
```

---

## 🔍 SEARCH & FILTER APIS

### 1. Search Students
**Endpoint:** `GET /api/students/search?keyword={keyword}`

**Description:** Search students by name or department (case-insensitive)

**Example:** `GET /api/students/search?keyword=john`

**Success Response (200 OK):**
```json
[
  {
    "id": 1,
    "name": "John Doe",
    "email": "john.doe@example.com",
    "department": "Computer Science",
    "year": 3,
    "phoneNumber": "9876543210"
  }
]
```

---

### 2. Get Students by Department
**Endpoint:** `GET /api/students/department/{department}`

**Description:** Filter students by department

**Example:** `GET /api/students/department/Computer Science`

**Success Response (200 OK):**
```json
[
  {
    "id": 1,
    "name": "John Doe",
    "email": "john.doe@example.com",
    "department": "Computer Science",
    "year": 3,
    "phoneNumber": "9876543210"
  }
]
```

---

### 3. Get Students by Year
**Endpoint:** `GET /api/students/year/{year}`

**Description:** Filter students by academic year

**Example:** `GET /api/students/year/3`

**Success Response (200 OK):**
```json
[
  {
    "id": 1,
    "name": "John Doe",
    "email": "john.doe@example.com",
    "department": "Computer Science",
    "year": 3,
    "phoneNumber": "9876543210"
  }
]
```

---

### 4. Get Students with Pagination
**Endpoint:** `GET /api/students/paginated`

**Description:** Get students with pagination and sorting

**Query Parameters:**
- `page` (optional, default: 0) - Page number (0-indexed)
- `size` (optional, default: 10) - Number of records per page
- `sortBy` (optional, default: "id") - Field to sort by
- `direction` (optional, default: "asc") - Sort direction (asc/desc)

**Example:** `GET /api/students/paginated?page=0&size=10&sortBy=name&direction=asc`

**Success Response (200 OK):**
```json
{
  "content": [
    {
      "id": 1,
      "name": "Alice Johnson",
      "email": "alice@example.com",
      "department": "Computer Science",
      "year": 3,
      "phoneNumber": "9876543210"
    }
  ],
  "pageable": {
    "pageNumber": 0,
    "pageSize": 10,
    "sort": {
      "sorted": true,
      "unsorted": false
    }
  },
  "totalPages": 5,
  "totalElements": 50,
  "last": false,
  "size": 10,
  "number": 0,
  "first": true,
  "numberOfElements": 10
}
```

---

### 5. Search with Pagination
**Endpoint:** `GET /api/students/search/paginated`

**Description:** Search students with pagination

**Query Parameters:**
- `keyword` (required) - Search keyword
- `page` (optional, default: 0)
- `size` (optional, default: 10)
- `sortBy` (optional, default: "id")
- `direction` (optional, default: "asc")

**Example:** `GET /api/students/search/paginated?keyword=john&page=0&size=10&sortBy=name&direction=asc`

**Success Response (200 OK):** Same structure as pagination response

---

## ❌ ERROR RESPONSES

### Common HTTP Status Codes

| Status Code | Meaning | When It Occurs |
|------------|---------|----------------|
| 200 OK | Success | Successful GET, PUT, DELETE |
| 201 Created | Resource created | Successful POST |
| 400 Bad Request | Invalid input | Validation errors |
| 401 Unauthorized | Authentication failed | Invalid credentials |
| 404 Not Found | Resource not found | Student/User not found |
| 409 Conflict | Duplicate resource | Duplicate email/username |
| 500 Internal Server Error | Server error | Unexpected errors |

### Error Response Format
All error responses follow this structure:
```json
{
  "timestamp": "2024-01-07T10:30:00",
  "status": 404,
  "error": "Not Found",
  "message": "Student not found with id : '1'",
  "path": "/api/students/1"
}
```

---

## 🧪 TESTING WITH POSTMAN

### Setup
1. Create a new Postman Collection named "Student Management System"
2. Set base URL variable: `{{baseUrl}}` = `http://localhost:8080/api`

### Test Sequence

#### 1. Register Admin
```
POST {{baseUrl}}/auth/register
Body (JSON):
{
  "username": "testadmin",
  "email": "test@example.com",
  "password": "test123"
}
```

#### 2. Login
```
POST {{baseUrl}}/auth/login
Body (JSON):
{
  "username": "testadmin",
  "password": "test123"
}
```

#### 3. Create Student
```
POST {{baseUrl}}/students
Body (JSON):
{
  "name": "Test Student",
  "email": "test.student@example.com",
  "department": "Computer Science",
  "year": 3,
  "phoneNumber": "9876543210"
}
```

#### 4. Get All Students
```
GET {{baseUrl}}/students
```

#### 5. Get Student by ID
```
GET {{baseUrl}}/students/1
```

#### 6. Update Student
```
PUT {{baseUrl}}/students/1
Body (JSON):
{
  "name": "Updated Student",
  "email": "updated@example.com",
  "department": "Electronics",
  "year": 4,
  "phoneNumber": "9876543211"
}
```

#### 7. Search Students
```
GET {{baseUrl}}/students/search?keyword=test
```

#### 8. Filter by Department
```
GET {{baseUrl}}/students/department/Computer Science
```

#### 9. Delete Student
```
DELETE {{baseUrl}}/students/1
```

---

## 📝 INTERVIEW QUESTIONS ON REST APIs

### Q1: What is REST?
**A:** Representational State Transfer - an architectural style for designing networked applications. It uses standard HTTP methods (GET, POST, PUT, DELETE) to perform CRUD operations.

### Q2: What are HTTP Methods and their purposes?
**A:** 
- GET: Retrieve data
- POST: Create new resource
- PUT: Update existing resource
- DELETE: Remove resource
- PATCH: Partial update (not used in this project)

### Q3: What is the difference between PUT and POST?
**A:** 
- POST: Creates a new resource, not idempotent
- PUT: Updates existing resource, idempotent (same request multiple times = same result)

### Q4: What is @RestController vs @Controller?
**A:** 
- @RestController = @Controller + @ResponseBody
- @RestController automatically serializes return values to JSON
- @Controller returns views (HTML pages)

### Q5: What is @RequestBody?
**A:** Binds HTTP request body to a method parameter. Automatically converts JSON to Java object.

### Q6: What is @PathVariable?
**A:** Extracts values from URI template. Example: `/students/{id}` → `@PathVariable Long id`

### Q7: What is @RequestParam?
**A:** Extracts query parameters. Example: `/search?keyword=john` → `@RequestParam String keyword`

### Q8: What is Content-Type header?
**A:** Specifies the format of request/response body. 
- `application/json` for JSON
- `application/xml` for XML

### Q9: Why use DTOs instead of Entities?
**A:** 
- Security: Don't expose internal structure
- Flexibility: Different API contracts than database
- Decoupling: Changes to entity don't affect API
- Validation: Different validation rules for API

### Q10: What is CORS and why do we need it?
**A:** Cross-Origin Resource Sharing - security feature that allows/blocks requests from different origins. Needed when frontend (port 5500) calls backend (port 8080).

---

## 🔒 SECURITY NOTES

**Current Implementation:**
- Simplified authentication (plain text passwords)
- No session management
- No rate limiting

**Production Recommendations:**
1. Use Spring Security
2. Implement BCrypt password encryption
3. Add JWT tokens for authentication
4. Implement rate limiting
5. Add HTTPS/SSL
6. Validate all inputs
7. Implement proper CORS policies
8. Add API authentication (API keys)
9. Implement request logging
10. Add security headers

---

## 📚 ADDITIONAL RESOURCES

- [Spring Boot Documentation](https://spring.io/projects/spring-boot)
- [Spring Data JPA](https://spring.io/projects/spring-data-jpa)
- [REST API Best Practices](https://restfulapi.net/)
- [HTTP Status Codes](https://httpstatuses.com/)
