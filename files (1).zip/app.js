/**
 * Student Management System - Frontend JavaScript
 * 
 * This file contains all the client-side logic for:
 * - Authentication (Login/Register)
 * - CRUD operations on students
 * - Search and filtering
 * - Pagination
 * - UI interactions
 * 
 * Interview Tips:
 * - Uses Fetch API for HTTP requests
 * - Implements async/await for cleaner asynchronous code
 * - Uses try-catch for error handling
 * - Follows single responsibility principle
 */

// ===================================
// GLOBAL VARIABLES & CONFIGURATION
// ===================================

const API_BASE_URL = 'http://localhost:8080/api';
let currentUser = null;
let allStudents = [];
let filteredStudents = [];
let currentPage = 0;
let pageSize = 10;
let totalPages = 0;
let isEditMode = false;
let editingStudentId = null;

// ===================================
// INITIALIZATION
// ===================================

/**
 * Initialize application on page load
 * Check if user is already logged in (from sessionStorage)
 */
document.addEventListener('DOMContentLoaded', function() {
    checkLoginStatus();
});

/**
 * Check if user is logged in
 */
function checkLoginStatus() {
    const user = sessionStorage.getItem('currentUser');
    if (user) {
        currentUser = JSON.parse(user);
        showDashboard();
        loadStudents();
    } else {
        showAuthSection();
    }
}

// ===================================
// AUTHENTICATION FUNCTIONS
// ===================================

/**
 * Toggle between login and register forms
 */
function toggleAuthForm() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    if (loginForm.style.display === 'none') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
    }
}

/**
 * Handle login form submission
 * 
 * Interview Tip: async/await makes asynchronous code more readable
 */
async function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            currentUser = {
                username: data.username,
                email: data.email,
                role: data.role
            };
            sessionStorage.setItem('currentUser', JSON.stringify(currentUser));
            showToast('Login successful!', 'success');
            showDashboard();
            loadStudents();
        } else {
            showToast(data.message || 'Invalid credentials', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showToast('Login failed. Please check your connection.', 'error');
    } finally {
        hideLoading();
    }
}

/**
 * Handle register form submission
 */
async function handleRegister(event) {
    event.preventDefault();
    
    const username = document.getElementById('registerUsername').value;
    const email = document.getElementById('registerEmail').value;
    const password = document.getElementById('registerPassword').value;
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, email, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showToast('Registration successful! Please login.', 'success');
            toggleAuthForm();
            document.getElementById('registerForm').reset();
        } else {
            showToast(data.message || 'Registration failed', 'error');
        }
    } catch (error) {
        console.error('Registration error:', error);
        showToast('Registration failed. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

/**
 * Logout user
 */
function logout() {
    sessionStorage.removeItem('currentUser');
    currentUser = null;
    showToast('Logged out successfully', 'success');
    showAuthSection();
}

/**
 * Show authentication section
 */
function showAuthSection() {
    document.getElementById('authSection').style.display = 'flex';
    document.getElementById('dashboardSection').style.display = 'none';
    document.getElementById('navUser').style.display = 'none';
}

/**
 * Show dashboard section
 */
function showDashboard() {
    document.getElementById('authSection').style.display = 'none';
    document.getElementById('dashboardSection').style.display = 'block';
    document.getElementById('navUser').style.display = 'flex';
    document.getElementById('welcomeText').textContent = `Welcome, ${currentUser.username}!`;
}

// ===================================
// STUDENT CRUD OPERATIONS
// ===================================

/**
 * Load all students from API
 * 
 * Interview Tip: This demonstrates API integration and error handling
 */
async function loadStudents() {
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/students`);
        
        if (response.ok) {
            allStudents = await response.json();
            filteredStudents = [...allStudents];
            displayStudents(filteredStudents);
        } else {
            showToast('Failed to load students', 'error');
        }
    } catch (error) {
        console.error('Error loading students:', error);
        showToast('Error loading students. Please check your connection.', 'error');
    } finally {
        hideLoading();
    }
}

/**
 * Display students in table
 */
function displayStudents(students) {
    const tbody = document.getElementById('studentsTableBody');
    const noDataMessage = document.getElementById('noDataMessage');
    
    tbody.innerHTML = '';
    
    if (students.length === 0) {
        noDataMessage.style.display = 'block';
        return;
    }
    
    noDataMessage.style.display = 'none';
    
    students.forEach(student => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.email}</td>
            <td>${student.department}</td>
            <td>${student.year}</td>
            <td>${student.phoneNumber}</td>
            <td class="actions">
                <button class="btn btn-warning btn-sm" onclick="editStudent(${student.id})">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-danger btn-sm" onclick="deleteStudent(${student.id})">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

/**
 * Show add student modal
 */
function showAddModal() {
    isEditMode = false;
    editingStudentId = null;
    document.getElementById('modalTitle').textContent = 'Add New Student';
    document.getElementById('studentForm').reset();
    document.getElementById('studentId').value = '';
    document.getElementById('studentModal').style.display = 'block';
}

/**
 * Edit student - load data into modal
 */
async function editStudent(id) {
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/students/${id}`);
        
        if (response.ok) {
            const student = await response.json();
            isEditMode = true;
            editingStudentId = id;
            
            document.getElementById('modalTitle').textContent = 'Edit Student';
            document.getElementById('studentId').value = student.id;
            document.getElementById('studentName').value = student.name;
            document.getElementById('studentEmail').value = student.email;
            document.getElementById('studentDepartment').value = student.department;
            document.getElementById('studentYear').value = student.year;
            document.getElementById('studentPhone').value = student.phoneNumber;
            
            document.getElementById('studentModal').style.display = 'block';
        } else {
            showToast('Failed to load student data', 'error');
        }
    } catch (error) {
        console.error('Error loading student:', error);
        showToast('Error loading student data', 'error');
    } finally {
        hideLoading();
    }
}

/**
 * Handle student form submission (Add or Update)
 * 
 * Interview Tip: This function handles both create and update operations
 */
async function handleSubmitStudent(event) {
    event.preventDefault();
    
    const studentData = {
        name: document.getElementById('studentName').value,
        email: document.getElementById('studentEmail').value,
        department: document.getElementById('studentDepartment').value,
        year: parseInt(document.getElementById('studentYear').value),
        phoneNumber: document.getElementById('studentPhone').value
    };
    
    showLoading();
    
    try {
        let response;
        
        if (isEditMode) {
            // Update existing student
            response = await fetch(`${API_BASE_URL}/students/${editingStudentId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(studentData)
            });
        } else {
            // Create new student
            response = await fetch(`${API_BASE_URL}/students`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(studentData)
            });
        }
        
        if (response.ok) {
            showToast(isEditMode ? 'Student updated successfully!' : 'Student added successfully!', 'success');
            closeModal();
            loadStudents();
        } else {
            const error = await response.json();
            showToast(error.message || 'Operation failed', 'error');
        }
    } catch (error) {
        console.error('Error saving student:', error);
        showToast('Error saving student', 'error');
    } finally {
        hideLoading();
    }
}

/**
 * Delete student
 */
async function deleteStudent(id) {
    if (!confirm('Are you sure you want to delete this student?')) {
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/students/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showToast('Student deleted successfully!', 'success');
            loadStudents();
        } else {
            showToast('Failed to delete student', 'error');
        }
    } catch (error) {
        console.error('Error deleting student:', error);
        showToast('Error deleting student', 'error');
    } finally {
        hideLoading();
    }
}

/**
 * Close modal
 */
function closeModal() {
    document.getElementById('studentModal').style.display = 'none';
    document.getElementById('studentForm').reset();
}

// ===================================
// SEARCH AND FILTER FUNCTIONS
// ===================================

/**
 * Handle search input
 * 
 * Interview Tip: Uses debouncing technique to avoid too many API calls
 */
let searchTimeout;
function handleSearch() {
    clearTimeout(searchTimeout);
    
    searchTimeout = setTimeout(async () => {
        const keyword = document.getElementById('searchInput').value.trim();
        
        if (keyword === '') {
            filteredStudents = [...allStudents];
            displayStudents(filteredStudents);
            return;
        }
        
        showLoading();
        
        try {
            const response = await fetch(`${API_BASE_URL}/students/search?keyword=${encodeURIComponent(keyword)}`);
            
            if (response.ok) {
                filteredStudents = await response.json();
                displayStudents(filteredStudents);
            } else {
                showToast('Search failed', 'error');
            }
        } catch (error) {
            console.error('Search error:', error);
            showToast('Search error', 'error');
        } finally {
            hideLoading();
        }
    }, 300); // 300ms delay
}

/**
 * Filter by department
 */
async function handleDepartmentFilter() {
    const department = document.getElementById('departmentFilter').value;
    
    if (department === '') {
        loadStudents();
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/students/department/${encodeURIComponent(department)}`);
        
        if (response.ok) {
            filteredStudents = await response.json();
            displayStudents(filteredStudents);
        } else {
            showToast('Filter failed', 'error');
        }
    } catch (error) {
        console.error('Filter error:', error);
        showToast('Filter error', 'error');
    } finally {
        hideLoading();
    }
}

/**
 * Filter by year
 */
async function handleYearFilter() {
    const year = document.getElementById('yearFilter').value;
    
    if (year === '') {
        loadStudents();
        return;
    }
    
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE_URL}/students/year/${year}`);
        
        if (response.ok) {
            filteredStudents = await response.json();
            displayStudents(filteredStudents);
        } else {
            showToast('Filter failed', 'error');
        }
    } catch (error) {
        console.error('Filter error:', error);
        showToast('Filter error', 'error');
    } finally {
        hideLoading();
    }
}

/**
 * Handle sorting
 * 
 * Interview Tip: Client-side sorting for better performance
 */
function handleSort() {
    const sortBy = document.getElementById('sortBy').value;
    const direction = document.getElementById('sortDirection').value;
    
    filteredStudents.sort((a, b) => {
        let aVal = a[sortBy];
        let bVal = b[sortBy];
        
        // Handle string comparison (case-insensitive)
        if (typeof aVal === 'string') {
            aVal = aVal.toLowerCase();
            bVal = bVal.toLowerCase();
        }
        
        if (direction === 'asc') {
            return aVal > bVal ? 1 : -1;
        } else {
            return aVal < bVal ? 1 : -1;
        }
    });
    
    displayStudents(filteredStudents);
}

/**
 * Reset all filters
 */
function resetFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('departmentFilter').value = '';
    document.getElementById('yearFilter').value = '';
    document.getElementById('sortBy').value = 'id';
    document.getElementById('sortDirection').value = 'asc';
    loadStudents();
}

// ===================================
// UI HELPER FUNCTIONS
// ===================================

/**
 * Show loading spinner
 */
function showLoading() {
    document.getElementById('loadingSpinner').style.display = 'flex';
}

/**
 * Hide loading spinner
 */
function hideLoading() {
    document.getElementById('loadingSpinner').style.display = 'none';
}

/**
 * Show toast notification
 * 
 * @param {string} message - Message to display
 * @param {string} type - Type of toast: 'success', 'error', 'warning'
 * 
 * Interview Tip: Toast notifications improve user experience
 */
function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type}`;
    toast.style.display = 'block';
    
    // Auto-hide after 3 seconds
    setTimeout(() => {
        toast.style.display = 'none';
    }, 3000);
}

// ===================================
// EVENT LISTENERS
// ===================================

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('studentModal');
    if (event.target === modal) {
        closeModal();
    }
}

// Close modal on Escape key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeModal();
    }
});

/**
 * INTERVIEW TALKING POINTS:
 * 
 * 1. Architecture:
 *    - Separation of concerns (auth, CRUD, UI)
 *    - Single Responsibility Principle
 *    - DRY (Don't Repeat Yourself)
 * 
 * 2. Async Operations:
 *    - Used async/await for cleaner code
 *    - Proper error handling with try-catch
 *    - Loading states for better UX
 * 
 * 3. User Experience:
 *    - Toast notifications for feedback
 *    - Loading spinners for async operations
 *    - Form validation
 *    - Confirmation dialogs for destructive actions
 * 
 * 4. Performance:
 *    - Debouncing for search (prevents too many API calls)
 *    - Client-side sorting when possible
 *    - SessionStorage for user state
 * 
 * 5. Best Practices:
 *    - Proper error handling
 *    - RESTful API integration
 *    - Responsive design
 *    - Accessibility considerations
 */
