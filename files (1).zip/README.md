# 🎓 Student Management System

A comprehensive full-stack web application for managing student records, built with Spring Boot and modern web technologies. Perfect for placement preparation and technical interviews!

![Java](https://img.shields.io/badge/Java-17-orange)
![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.2-green)
![MySQL](https://img.shields.io/badge/MySQL-8.0-blue)
![License](https://img.shields.io/badge/License-MIT-yellow)

## 📋 Table of Contents
- [Features](#-features)
- [Tech Stack](#-tech-stack)
- [Project Structure](#-project-structure)
- [Getting Started](#-getting-started)
- [API Documentation](#-api-documentation)
- [Screenshots](#-screenshots)
- [Interview Preparation](#-interview-preparation)
- [Contributing](#-contributing)

---

## ✨ Features

### Core Features
- ✅ **User Authentication** - Admin login and registration
- ✅ **CRUD Operations** - Create, Read, Update, Delete students
- ✅ **Search & Filter** - Search by name/department, filter by year
- ✅ **Sorting** - Sort by any field (name, email, department, year)
- ✅ **Pagination** - Efficient loading of large datasets
- ✅ **Input Validation** - Comprehensive validation on both frontend and backend
- ✅ **Error Handling** - Global exception handling with meaningful messages
- ✅ **Responsive Design** - Works on desktop, tablet, and mobile

### Technical Features
- 🏗️ **Layered Architecture** - Clean separation of concerns
- 🔐 **Security** - Input validation and error handling
- 📊 **RESTful APIs** - Well-designed REST endpoints
- 🗄️ **Database Design** - Optimized MySQL schema with indexes
- 🎨 **Modern UI** - Clean, professional interface
- 📱 **Responsive** - Mobile-friendly design

---

## 🛠️ Tech Stack

### Backend
- **Framework:** Spring Boot 3.2
- **Language:** Java 17
- **ORM:** Spring Data JPA + Hibernate
- **Database:** MySQL 8.0
- **Build Tool:** Maven 3.8+
- **Validation:** Bean Validation (Hibernate Validator)

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with Flexbox and Grid
- **JavaScript (ES6+)** - Async/await, Fetch API
- **Font Awesome** - Icons

### Architecture
- **Pattern:** MVC (Model-View-Controller)
- **Design:** Layered Architecture
- **API:** RESTful API design

---

## 📁 Project Structure

```
student-management-system/
│
├── backend/                                 # Spring Boot Backend
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/placement/studentms/
│   │   │   │   ├── controller/             # REST Controllers
│   │   │   │   │   ├── StudentController.java
│   │   │   │   │   └── AuthController.java
│   │   │   │   ├── service/                # Business Logic
│   │   │   │   │   ├── StudentService.java
│   │   │   │   │   └── AuthService.java
│   │   │   │   ├── repository/             # Data Access Layer
│   │   │   │   │   ├── StudentRepository.java
│   │   │   │   │   └── AdminUserRepository.java
│   │   │   │   ├── model/                  # Entity Classes
│   │   │   │   │   ├── Student.java
│   │   │   │   │   └── AdminUser.java
│   │   │   │   ├── dto/                    # Data Transfer Objects
│   │   │   │   │   ├── StudentDTO.java
│   │   │   │   │   └── AuthDTO.java
│   │   │   │   ├── exception/              # Exception Handling
│   │   │   │   │   ├── GlobalExceptionHandler.java
│   │   │   │   │   ├── ResourceNotFoundException.java
│   │   │   │   │   └── CustomExceptions.java
│   │   │   │   └── StudentManagementSystemApplication.java
│   │   │   └── resources/
│   │   │       └── application.properties   # Configuration
│   │   └── test/                            # Test cases
│   └── pom.xml                              # Maven dependencies
│
├── frontend/                                # Frontend Application
│   ├── index.html                           # Main HTML file
│   ├── css/
│   │   └── styles.css                       # Styling
│   └── js/
│       └── app.js                           # JavaScript logic
│
└── docs/                                    # Documentation
    ├── database_schema.sql                  # Database schema
    ├── API_DOCUMENTATION.md                 # API reference
    ├── SETUP_GUIDE.md                       # Setup instructions
    ├── INTERVIEW_GUIDE.md                   # Interview preparation
    └── README.md                            # This file
```

---

## 🚀 Getting Started

### Prerequisites
- Java 17 or higher
- Maven 3.6+
- MySQL 8.0+
- Any modern web browser
- (Optional) Postman for API testing

### Quick Start

#### 1. Clone the Repository
```bash
git clone <repository-url>
cd student-management-system
```

#### 2. Setup Database
```bash
# Login to MySQL
mysql -u root -p

# Create database
CREATE DATABASE student_management_db;

# Run schema script
mysql -u root -p student_management_db < docs/database_schema.sql
```

#### 3. Configure Backend
Edit `backend/src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/student_management_db
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD
```

#### 4. Run Backend
```bash
cd backend
mvn clean install
mvn spring-boot:run
```

Backend will start on: http://localhost:8080

#### 5. Run Frontend
```bash
cd frontend

# Option 1: Python HTTP Server
python -m http.server 8000

# Option 2: Node.js HTTP Server
npx http-server -p 8000

# Option 3: VS Code Live Server extension
# Right-click index.html → Open with Live Server
```

Frontend will be available at: http://localhost:8000

#### 6. Login
Default credentials:
- Username: `admin`
- Password: `admin123`

---

## 📚 API Documentation

### Base URL
```
http://localhost:8080/api
```

### Authentication Endpoints

#### Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "username": "admin",
  "email": "admin@example.com",
  "password": "admin123"
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```

### Student Endpoints

#### Create Student
```http
POST /api/students
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "department": "Computer Science",
  "year": 3,
  "phoneNumber": "9876543210"
}
```

#### Get All Students
```http
GET /api/students
```

#### Get Student by ID
```http
GET /api/students/{id}
```

#### Update Student
```http
PUT /api/students/{id}
Content-Type: application/json

{
  "name": "John Doe Updated",
  "email": "john.updated@example.com",
  "department": "Computer Science",
  "year": 4,
  "phoneNumber": "9876543210"
}
```

#### Delete Student
```http
DELETE /api/students/{id}
```

#### Search Students
```http
GET /api/students/search?keyword=john
```

#### Filter by Department
```http
GET /api/students/department/Computer Science
```

#### Filter by Year
```http
GET /api/students/year/3
```

#### Pagination
```http
GET /api/students/paginated?page=0&size=10&sortBy=name&direction=asc
```

**For complete API documentation, see [API_DOCUMENTATION.md](docs/API_DOCUMENTATION.md)**

---

## 📸 Screenshots

### Login Page
Clean and professional authentication interface

### Dashboard
Comprehensive student management interface with all CRUD operations

### Add/Edit Student
Modal form with validation for adding or editing students

### Search & Filter
Real-time search with department and year filters

---

## 🎯 Key Concepts Demonstrated

### Backend Concepts
- ✅ Spring Boot application development
- ✅ RESTful API design and implementation
- ✅ Spring Data JPA and Hibernate ORM
- ✅ MySQL database design and optimization
- ✅ Layered architecture (Controller-Service-Repository)
- ✅ DTO pattern for API security
- ✅ Bean Validation for input validation
- ✅ Global exception handling with @RestControllerAdvice
- ✅ Custom exceptions and error responses
- ✅ CORS configuration
- ✅ Transaction management
- ✅ Pagination and sorting
- ✅ Custom JPA queries

### Frontend Concepts
- ✅ Responsive web design
- ✅ Fetch API for HTTP requests
- ✅ Async/await for asynchronous operations
- ✅ DOM manipulation
- ✅ Event handling
- ✅ Form validation
- ✅ Error handling and user feedback
- ✅ Debouncing for search optimization
- ✅ Modal dialogs
- ✅ Dynamic content rendering

### Database Concepts
- ✅ Database schema design
- ✅ Primary keys and auto-increment
- ✅ Unique constraints
- ✅ Indexes for query optimization
- ✅ Data types selection
- ✅ Audit fields (created_at, updated_at)
- ✅ SQL queries for CRUD operations

---

## 💼 Interview Preparation

This project is perfect for technical interviews! Here's what it demonstrates:

### Technical Skills
1. **Full-Stack Development** - Frontend + Backend + Database
2. **REST API Design** - RESTful principles and best practices
3. **Database Design** - Normalized schema with proper indexing
4. **Error Handling** - Comprehensive exception management
5. **Input Validation** - Both client-side and server-side
6. **Code Organization** - Clean architecture and separation of concerns
7. **Design Patterns** - MVC, Repository, DTO, Singleton

### Common Interview Questions Covered
- Explain Spring Boot architecture
- What is dependency injection?
- How does JPA/Hibernate work?
- What are RESTful APIs?
- How do you handle exceptions in Spring Boot?
- What is the difference between @Controller and @RestController?
- How do you prevent SQL injection?
- What is CORS and why is it needed?
- How would you optimize database queries?
- How would you scale this application?

**For detailed interview preparation, see [INTERVIEW_GUIDE.md](docs/INTERVIEW_GUIDE.md)**

---

## 📖 Documentation

Comprehensive documentation is available in the `docs/` folder:

- **[SETUP_GUIDE.md](docs/SETUP_GUIDE.md)** - Detailed setup instructions
- **[API_DOCUMENTATION.md](docs/API_DOCUMENTATION.md)** - Complete API reference
- **[INTERVIEW_GUIDE.md](docs/INTERVIEW_GUIDE.md)** - Interview preparation guide
- **[database_schema.sql](docs/database_schema.sql)** - Database schema with explanations

---

## 🔧 Configuration

### Application Properties
Key configurations in `application.properties`:

```properties
# Server Port
server.port=8080

# Database Configuration
spring.datasource.url=jdbc:mysql://localhost:3306/student_management_db
spring.datasource.username=root
spring.datasource.password=root

# JPA Configuration
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true

# Logging
logging.level.com.placement.studentms=DEBUG
```

---

## 🧪 Testing

### Manual Testing
1. Start backend and frontend
2. Register a new admin user
3. Login with credentials
4. Perform all CRUD operations
5. Test search and filter functionality
6. Test validation errors

### API Testing with Postman
1. Import API collection
2. Test all endpoints
3. Verify status codes
4. Check error responses

### Automated Testing (Future Enhancement)
```bash
cd backend
mvn test
```

---

## 🚀 Deployment

### Deploy Backend
**Heroku:**
```bash
heroku create student-mgmt-api
heroku addons:create cleardb:ignite
git push heroku main
```

**AWS EC2:**
1. Package application: `mvn clean package`
2. Upload JAR to EC2
3. Run: `java -jar app.jar`

### Deploy Frontend
**Netlify:**
1. Connect GitHub repository
2. Configure build settings
3. Deploy

**Vercel:**
```bash
vercel deploy
```

---

## 🤝 Contributing

Contributions are welcome! Here's how:

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 🔮 Future Enhancements

- [ ] Spring Security with JWT authentication
- [ ] Password encryption with BCrypt
- [ ] Role-based access control (Admin, Teacher, Student)
- [ ] Email notifications
- [ ] File upload (profile pictures, documents)
- [ ] Export to Excel/PDF
- [ ] Advanced analytics and reports
- [ ] Attendance management
- [ ] Grade management
- [ ] Unit and integration tests
- [ ] Docker containerization
- [ ] CI/CD pipeline
- [ ] Redis caching
- [ ] Microservices architecture

---

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

## 👨‍💻 Author

**Your Name**
- GitHub: [@yourusername](https://github.com/yourusername)
- LinkedIn: [Your LinkedIn](https://linkedin.com/in/yourprofile)
- Email: your.email@example.com

---

## 🙏 Acknowledgments

- Spring Boot Documentation
- Baeldung Tutorials
- Stack Overflow Community
- Font Awesome for icons
- MySQL Documentation

---

## 📞 Support

If you have any questions or need help with setup:

1. Check the [SETUP_GUIDE.md](docs/SETUP_GUIDE.md)
2. Review [API_DOCUMENTATION.md](docs/API_DOCUMENTATION.md)
3. Open an issue on GitHub
4. Contact via email

---

## ⭐ Show Your Support

If this project helped you in your placement preparation, please give it a ⭐️!

---

**Happy Coding! 🚀**
