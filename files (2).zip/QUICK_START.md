# 🚀 QUICK START GUIDE - Student Management System

## Get Started in 5 Minutes!

### Prerequisites Check
- ✅ Java 17+ installed? Run: `java -version`
- ✅ Maven installed? Run: `mvn -version`
- ✅ MySQL installed? Run: `mysql --version`

---

## Step 1: Setup Database (2 minutes)

```bash
# Login to MySQL
mysql -u root -p

# Copy and paste these commands:
CREATE DATABASE student_management_db;
USE student_management_db;
exit;

# Run the schema script
mysql -u root -p student_management_db < docs/database_schema.sql
```

---

## Step 2: Configure Backend (1 minute)

Edit `backend/src/main/resources/application.properties`:

```properties
# Change only this line with YOUR MySQL password:
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

---

## Step 3: Start Backend (1 minute)

```bash
cd backend
mvn spring-boot:run
```

Wait for: "Student Management System Started!"

Keep this terminal running!

---

## Step 4: Start Frontend (1 minute)

Open a NEW terminal:

```bash
cd frontend
python -m http.server 8000
```

---

## Step 5: Open Browser

Go to: **http://localhost:8000**

**Login with:**
- Username: `admin`
- Password: `admin123`

---

## 🎉 You're Ready!

Now you can:
- ✅ Add students
- ✅ Edit students
- ✅ Delete students
- ✅ Search students
- ✅ Filter by department/year

---

## ❌ Troubleshooting

**Backend won't start?**
- Check MySQL is running
- Verify password in application.properties
- Ensure port 8080 is free

**Frontend can't connect to backend?**
- Make sure backend is running (check terminal)
- Verify backend shows "Student Management System Started!"
- Check http://localhost:8080/api/students in browser

**"Access Denied" error?**
- MySQL username/password wrong in application.properties
- Try: `spring.datasource.username=root`

---

## 📖 Need More Help?

See detailed documentation:
- **SETUP_GUIDE.md** - Complete setup instructions
- **API_DOCUMENTATION.md** - API reference
- **INTERVIEW_GUIDE.md** - Interview preparation

---

## 🎯 Test Your Setup

Try these in order:

1. **Can you login?** ✓
2. **Can you add a student?** ✓
3. **Can you see the student in the table?** ✓
4. **Can you edit the student?** ✓
5. **Can you search for the student?** ✓
6. **Can you delete the student?** ✓

If all ✓ = **SUCCESS!** 🎊

---

## 💡 Pro Tips

1. **Use Postman** - Test APIs independently
2. **Check browser console (F12)** - See frontend errors
3. **Check backend terminal** - See backend logs
4. **Default admin already exists** - No need to register first time

---

## 📱 Quick Demo Flow

1. Login with admin/admin123
2. Click "Add New Student"
3. Fill in:
   - Name: John Doe
   - Email: john@example.com
   - Department: Computer Science
   - Year: 3
   - Phone: 9876543210
4. Click "Save Student"
5. See John in the table!
6. Try searching: type "john" in search box
7. Try editing: click Edit button
8. Try deleting: click Delete button

---

**Happy Coding! 🚀**

Questions? Open an issue or check the detailed docs!
